package pojo;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Random;
import java.util.Map.Entry;

public class Record {
	
	private int recordId;
	private int clientId;
	private int serviceProviderId;
	private int r; 
	private int s;
	private int c;
	private int p;
	private int I;
	
	private double belief;
	private int cost;
	private int loss;
	
	static int numberOfRecords = 0;
	private static int percentPosFeedsOcurrence = 7;   //  70%
	private static int percentPraiseOcurrence = 8;    //  80%
	private static int maxMoney = 1000;
	
	public Record() {
	}
	
	public void setRecordId(int id) {
		this.recordId = id;
	}
	
	public int getRecordId() {
		return this.recordId;
	}
	
	
	public void setClientId(int id) {
		this.clientId = id;
	}
	
	public int getClientId() {
		return this.clientId;
	}
	
	
	public void setServiceProviderId(int id) {
		this.serviceProviderId = id;
	}
	
	public int getServiceProviderId() {
		return this.serviceProviderId;
	}
	
	
	public void setPositiveFeeds(int r) {
		this.r = r;
	}
	
	public int getPositiveFeeds() {
		return this.r;
	}
	
	
	public void setNegativeFeeds(int s) {
		this.s = s;
	}
	
	public int getNegativeFeeds() {
		return this.s;
	}
	
	
	public void setPraise(int p) {
		this.p = p;
//		this.p = this.getInteractions() - this.getComplaints();
	}
	
	public int getPraise() {
		return this.p;
	}
	
	
	public void setComplaints(int c) {
		this.c = c;
	}
	
	public int getComplaints() {
		return this.c;
	}
	
	
	public void setInteractions(int I) {
		this.I = I;
	}
	
	public int getInteractions() {
		return this.I;
	}
	
	
	public void setBelief(double belief) {
		this.belief = belief;
	}
	
	public double getBelief() {
		return this.belief;
	}
	
	public void setBelief() {
		this.belief = this.r / (double) (this.r + this.s);
	}
	
	
	public void setCost(int cost) {
		this.cost = cost;
	}
	
	public int getCost() {
		return this.cost;
	}
	
	
	public void setLoss(int loss) {
		this.loss = loss;
	}
	
	public int getLoss() {
		return this.loss;
	}

	public String toString() {
		return "clientId: " + clientId + ", serviceProviderId: " + serviceProviderId  + ", r = " + r + ", s = " + s + ", "
			   + "p = " + p + ", c = " + c + ", I = " + I + ", belief = " + belief + ", gain = " + cost + ", loss= " + loss;
	}
	
	
	public static int getPositiveByRate(int totalInteractions, int ocurrence, Random rand) {
		int numberOfpositives;
		
		++numberOfRecords;
		boolean isTimeForNegative= (ocurrence) % (numberOfRecords) == 0; 
		float rate = ocurrence / 10.0f;
		if (isTimeForNegative) {
			rate = 1 - rate;
			int threshold = (int) Math.ceil(rate * totalInteractions);
			numberOfpositives = rand.nextInt(totalInteractions);
		}
		else {
			int threshold = (int) Math.ceil(rate * totalInteractions);
			if ( threshold == totalInteractions )
					--threshold;
//			System.out.println("threshold = " +  threshold + " " + totalInteractions);
			
			numberOfpositives = rand.nextInt(totalInteractions - threshold) + threshold;
		//  numberOfpositives belongs to [threshold, totalInteractions)		
		}
		
		return numberOfpositives;
	}
	
	public static Record random(int maxNumberOfUsers, int maxNumberOfBuyers, int maxNumberOfInteractions) {
		Random rand = new Random();
		
		Record record = new Record();
		record.getClientId();
		record.setClientId( rand.nextInt(maxNumberOfBuyers) );
		record.setServiceProviderId( rand.nextInt(maxNumberOfUsers - maxNumberOfBuyers) + maxNumberOfBuyers  );
		
//		record.setInteractions( (int)0.5*maxNumberOfInteractions + rand.nextInt((int)(0.5*maxNumberOfInteractions)) + 1);
//		record.setInteractions( rand.nextInt(maxNumberOfInteractions) + 1);
		record.setInteractions(maxNumberOfInteractions);
			
		record.setPositiveFeeds( getPositiveByRate(record.getInteractions(), percentPosFeedsOcurrence, rand) );
		record.setNegativeFeeds( record.getInteractions() - record.getPositiveFeeds() );
		
		record.setPraise( getPositiveByRate( record.getInteractions(), percentPraiseOcurrence, rand) );
		record.setComplaints( record.getInteractions() - record.getPraise() );
		
		// added
		record.setBelief( record.getPositiveFeeds() / ( (double) record.getPositiveFeeds() + record.getNegativeFeeds() ) );
		record.setCost( (int)(0.5*maxMoney) + rand.nextInt((int)(0.5*maxMoney)) );
		record.setLoss( maxMoney - record.getCost() );
		// added
		
//		record.setInteractions( record.getPraise() + record.getComplaints() );
		
		return record;
	}

	/*       Comparators           */
	public static class ClientIdComparator implements Comparator<Record> {

		@Override
		public int compare(Record r1, Record r2) {
			// TODO Auto-generated method stub
			return r1.getClientId() - r2.getClientId();
		}
		
	}
	
	public static class ServiceProviderIdComparator implements Comparator<Record> {

		@Override
		public int compare(Record r1, Record r2) {
			// TODO Auto-generated method stub
			return r1.getServiceProviderId() - r2.getServiceProviderId();
		}
		
	}
	
	public static class ReputationComparator implements Comparator<Record> {

		private HashMap<Integer, Double> reputations;
		
		public ReputationComparator(HashMap<Integer, Double> reputations) {
			this.reputations = reputations;
		}
		
		@Override
		public int compare(Record r1, Record r2) {
			// TODO Auto-generated method stub
			return (int) ( reputations.get( r1.getServiceProviderId() ) - reputations.get( r2.getServiceProviderId() ) );
		}
		
	}
	
	
	public static int getMaxFrom(ArrayList<Record> records, Comparator<Record> comp) {
		int maxIndex = 0;
		for ( int i = 1; i < records.size(); ++i ) {
			if ( comp.compare( records.get(maxIndex), records.get(i) ) < 0 )
				maxIndex = i;
		}
		
		return maxIndex;
	}
	
	
	public static int getMinVarianceIndex(ArrayList<Record> records, HashMap<Integer, Double> reputations) {
		float avg = 0;
		for ( Entry<Integer, Double> entry: reputations.entrySet() ) {
				avg += entry.getValue();
		}
		
		float min = 1;  //  variance can be always < 1
		int serviceProviderId = 0;
		for ( Entry<Integer, Double> entry: reputations.entrySet() ) {
			float delta = (float) (entry.getValue() - avg);
			if ( delta < min) {
				min = delta;
				serviceProviderId = entry.getKey();
			}
		}
		
		int index = 0;
		for ( int i = 1; i < records.size(); ++i ) {
			if ( serviceProviderId == records.get(i).serviceProviderId )
				index = i;
		}
		
		return index;		
	}

	public static int getBySimilarPositiveFeeds(ArrayList<Record> records, int index) {
		int DIFF_R = 5;
		int indexSimilar = 0; 
		for ( int i = 0; i < index; ++i ) {
			if ( Math.abs( records.get(i).getPositiveFeeds() - records.get(index).getPositiveFeeds() ) < DIFF_R ) {
				indexSimilar = i;
				break;
			}
		}
		
		for ( int i = index+1; i < records.size(); ++i ) {
			if ( Math.abs( records.get(i).getPositiveFeeds() - records.get(index).getPositiveFeeds() ) < DIFF_R ) {
				indexSimilar = i;
				return indexSimilar;
			}
		}
		return indexSimilar;
	}

}