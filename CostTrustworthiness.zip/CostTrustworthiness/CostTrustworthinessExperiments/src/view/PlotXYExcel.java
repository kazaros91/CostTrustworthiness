package view;

import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

import converter.ExcelToPOJO;


public class PlotXYExcel {
	
	private String plotName;
	private String Xname;
	private String Yname;
	
	private XYSeriesCollection collection;
	
	public PlotXYExcel(String applicationTitle, String plotName, String Xname, String Yname) {
		this.plotName = plotName;
		this.Xname = Xname;
		this.Yname = Yname;
		
		collection = new XYSeriesCollection();
	}
	
	public void draw() {          
		// input the filename to generate figures in excel
		String outputFileName = "C:\\Users\\Ghazaros\\Desktop\\CostTrustworthinessFigures\\FiguresEditableExcel\\Scenario1\\Figure 3.xlsx";
		ExcelToPOJO converter = new ExcelToPOJO();
		converter.write(collection, outputFileName, this.Xname);
	}
	
	public static void main(String [] args) {
		
	}
	
	private static void test() {
		
	}

	public void add(XYSeries series) {
		collection.addSeries(series);
	}
}
