package view;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;

import javax.imageio.ImageIO;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.Plot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RefineryUtilities;
import org.jfree.util.Log;



public class PlotXY extends ApplicationFrame {

	private XYSeriesCollection collection;
	private XYLineAndShapeRenderer renderer;
	private String plotName;
	private String Xname;
	private String Yname;
	
	private int index = 0;
	private static Color [] colors = { Color.GREEN, Color.BLUE, Color.RED, Color.MAGENTA, Color.ORANGE, Color.BLACK }; 

	public PlotXY(String applicationTitle, String plotName, String Xname, String Yname)
	{
		 super(applicationTitle);
		 this.plotName = plotName;
		 this.Xname = Xname;
		 this.Yname = Yname;
		 this.index = 0;
		 
		 collection = new XYSeriesCollection();
		 renderer = new XYLineAndShapeRenderer();
	 }
	 
	private XYSeries convertToXYSeries(final ArrayList<Integer> f, String chartTitle)
	{
		final XYSeries output = new XYSeries(chartTitle) ; 
		for ( int i=0; i < f.size(); ++i )
		{
			output.add( i+1, f.get(i) );
		}
		
		return output;
	}
	
	public void add(final ArrayList<Integer> f, String chartTitle)
	{
		add( convertToXYSeries(f, chartTitle) );
	}
	
	public void add(final XYSeries series)
	{
		collection.addSeries( series);
		
		renderer.setSeriesPaint( index, colors[index] );
		renderer.setSeriesLinesVisible(index, false);
		renderer.setSeriesStroke( index++, new BasicStroke( 0.0f ) );
	}
	 
	public void draw()   //  draw XYLineChart
	{	
		JFreeChart xylineChart = ChartFactory.createXYLineChart(plotName, Xname , Yname , collection,
					PlotOrientation.VERTICAL ,
					true , true , false);

//		Toolkit.getDefaultToolkit().getScreenSize() 
		final XYPlot plot = xylineChart.getXYPlot( );
		plot.setRenderer( renderer );
		
		ChartPanel chartPanel = new ChartPanel( xylineChart );
		setContentPane(chartPanel);
		
		pack();
    	RefineryUtilities.centerFrameOnScreen( this);
    	setVisible( true );
	}
	
	public void draw0()   //  not revised
	{	
//		JFreeChart xylineChart = ChartFactory.createScatterPlot(plotName, Xname , Yname , collection);
		JFreeChart xylineChart = ChartFactory.createXYLineChart(plotName, Xname , Yname , collection,
				PlotOrientation.VERTICAL,
				true , true , false);

//		Toolkit.getDefaultToolkit().getScreenSize() 
		final XYPlot plot = xylineChart.getXYPlot();

		plot.setRenderer( renderer );
		
		ChartPanel chartPanel = new ChartPanel( xylineChart );
		setContentPane(chartPanel);
		
		pack();
    	RefineryUtilities.centerFrameOnScreen( this);
    	setVisible( true );
    	
    	String fileName = "C:\\Users\\Ghazaros\\Desktop\\paper_Trustworthiness_reputation\\Figures_editable_EPS\\Figure1.jpg";
//    	try {
//    		ChartUtilities.saveChartAsJPEG(new File(fileName), xylineChart, 800, 600);
//    	}
//    	catch (Exception e) { 
//			Log.error( e ); 
//		} 
    	writeAsEPS(xylineChart, 800, 600);   //  saving an image
	}
  
	public void writeAsEPS( JFreeChart chart, int width, int height ) { 
		try { 
			File outputFile =  new File("C:\\Users\\Ghazaros\\Desktop\\paper_Trustworthiness_reputation\\Figures_editable_EPS\\Figure1.ps");
			BufferedImage chartImage = chart.createBufferedImage(width, height, null); 
			ImageIO.write( chartImage, "ps", outputFile ); 
		} 
		catch (IOException e) { 
			System.out.println("NO EPSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS");; 
		} 
	} 
	
    public static void main(String[] args) {
//    	 PlotXY chart = new PlotXY( "Browser Usage Statistics" );
    }
    
}