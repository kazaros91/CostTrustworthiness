package converter;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Comparator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.javatuples.Pair;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

import pojo.Record;

public class ExcelToPOJO {
	
    private String getMax(File [] files, Comparator<File> comp) {
    	
    	File max = files[0];
    	for ( int i = 1; i < files.length; ++i ) {
    		if ( comp.compare( max, files[i] ) < 0 )
    			max = files[i];
    	}
    	
    	return max.getAbsolutePath();
    }
    
    public String getNewFileName() {
    	File folder = new File("C:\\Users\\Ghazaros\\Desktop\\CostTrustworthinessRecords");
    	File [] files = folder.listFiles() ;
//    	System.out.println( "last File Name without max " + files[ files.length - 1].getAbsolutePath() );
    	
    	FilePathComparator<File> comp = new FilePathComparator<File>();
    	String lastFileName = this.getMax(files, comp);
    	String newFileName = comp.getNextNewFileName(lastFileName);
//    	System.out.println( "get max file name " + lastFileName );
//    	System.out.println( "new file name " + newFileName );
    	
    	return newFileName;
    }
    
	public ExcelToPOJO () {}
	
	public ArrayList<Record> read(String inputFileName) {
		ArrayList<Record> records = new ArrayList<Record>(); 
		
		try { 	
			FileInputStream fs = new FileInputStream( new File(inputFileName) );
	        XSSFWorkbook workbook = new XSSFWorkbook(fs);
	        XSSFSheet sheet = workbook.getSheetAt(0);
		    XSSFRow row;
		    XSSFCell cell;
		    
		    int rows; // No of rows
		    rows = sheet.getPhysicalNumberOfRows();

		    //   reading data from the .xlsx file
		    for(int r = 1; r < rows; r++) {
		        row = sheet.getRow(r);
		        if(row != null) {

		        	//  converting a cell to a record
		        	Record record = new Record();

//		        	System.out.println( row.getCell(0).get );
		        	record.setClientId( (int) row.getCell(0).getNumericCellValue() );
		        	record.setServiceProviderId( (int) row.getCell(1).getNumericCellValue() );
		        	record.setPositiveFeeds( (int) row.getCell(2).getNumericCellValue() );
		        	record.setNegativeFeeds( (int) row.getCell(3).getNumericCellValue() );
		        	record.setPraise( (int) row.getCell(4).getNumericCellValue() );
		        	record.setComplaints( (int) row.getCell(5).getNumericCellValue() );
		        	record.setInteractions( (int) row.getCell(6).getNumericCellValue() );
		        	// added
		        	record.setBelief( (double) row.getCell(7).getNumericCellValue() );
		        	record.setCost( (int) row.getCell(8).getNumericCellValue() );
		        	record.setLoss( (int) row.getCell(9).getNumericCellValue() );
		        	// added
		        	
		        	//   storing in records
		        	records.add(record);

//		            for(int c = 0; c < cols; c++) {
//		                cell = row.getCell((short) c);
//		                if(cell != null) {
//		                    // the code coming here
//		                }
//		            }
		        }
		    }
		} catch(Exception ioe) {
		    ioe.printStackTrace();
		}
		
		return records;
	}
	
	private void giveNamesToColumns(XSSFSheet sheet) {
	//   give names to the columns
		Row row = sheet.createRow(0);
	    Cell cell;
	    cell = row.createCell(0); cell.setCellValue("ClientId");
	    cell = row.createCell(1); cell.setCellValue("ServiceProviderId");
	    cell = row.createCell(2); cell.setCellValue("r");
	    cell = row.createCell(3); cell.setCellValue("s");
	    cell = row.createCell(4); cell.setCellValue("p");
	    cell = row.createCell(5); cell.setCellValue("c");
	    cell = row.createCell(6); cell.setCellValue( "I" );
	    // added
	    cell = row.createCell(7); cell.setCellValue("belief");
	    cell = row.createCell(8); cell.setCellValue("gain");
	    cell = row.createCell(9); cell.setCellValue("loss");
	    // added
	}
	
	public void write(final ArrayList<Record> records, String outputFileName) {
		System.out.println( "The records will be stored in " + outputFileName );
		System.out.println( "please wait..." );
		
		//Blank workbook
	    XSSFWorkbook workbook = new XSSFWorkbook();
	    //Create a blank sheet
	    XSSFSheet sheet = workbook.createSheet("P2P transactions records data");
	    
	    giveNamesToColumns(sheet);
	    //   converting records to .xlsx
	    for ( int recordId = 0; recordId < records.size(); ++recordId ) {
	    	Record record = records.get(recordId);
	    	
	    	//   inserting the row containing in record
	    	Row row = sheet.createRow(recordId + 1);
	    	Cell cell;
	    	cell = row.createCell(0); cell.setCellValue( record.getClientId() );
	    	cell = row.createCell(1); cell.setCellValue( record.getServiceProviderId() );
	    	cell = row.createCell(2); cell.setCellValue( record.getPositiveFeeds() );
	    	cell = row.createCell(3); cell.setCellValue( record.getNegativeFeeds() );
	    	cell = row.createCell(4); cell.setCellValue( record.getPraise() );
	    	cell = row.createCell(5); cell.setCellValue( record.getComplaints() );
	    	cell = row.createCell(6); cell.setCellValue( record.getInteractions() );
	    	// added
	    	cell = row.createCell(7); cell.setCellValue( record.getBelief() );
	    	cell = row.createCell(8); cell.setCellValue( record.getCost() );
	    	cell = row.createCell(9); cell.setCellValue( record.getLoss() );
	    	// added
	    	
//	    	System.out.println(row.getCell(recordId).getStringCellValue());
	    }
	    try 
	    {
	        //Write the workbook in file system
	        FileOutputStream out = new FileOutputStream( new File(outputFileName) );
	        workbook.write(out);
	        out.close();
	        System.out.println("The records written successfully on the disk.");
	    } 
	    catch (Exception e)
	    {
	        e.printStackTrace();
	    }
	}
	
	public void write(final ArrayList<Record> records) {
		String outputFileName = this.getNewFileName();
		write(records, outputFileName);
	}
	
	private void giveSeriesNamesToColumns(XSSFSheet sheet, String Xname) {
	//   give names to the columns
		Row row = sheet.createRow(0);
		Cell cell;
		cell = row.createCell(0); cell.setCellValue(Xname);
		// the names for Y fields
		cell = row.createCell(1); cell.setCellValue("With Cost Based");
		cell = row.createCell(2); cell.setCellValue("No Cost Based");
		cell = row.createCell(3); cell.setCellValue("Beta");
	}
	
	public void write(XYSeriesCollection collection,  String outputFileName, String Xname) {
		XSSFWorkbook workbook = new XSSFWorkbook();
	    //Create a blank sheet
	    XSSFSheet sheet = workbook.createSheet("Trustworthiness Values");
	    
	    giveSeriesNamesToColumns(sheet, Xname);
	    //   converting records to .xlsx
	    XYSeries series1 = collection.getSeries(0);
	    for ( int i = 0; i < series1.getItemCount(); ++i ) {
	    	//   inserting the i-th XY values from the series
	    	Row row = sheet.createRow(i+1);
	    	Cell cell;
	    	cell = row.createCell(0); cell.setCellValue( (double) collection.getSeries(0).getX(i) );
	    	for ( int j = 0; j < collection.getSeriesCount(); ++j ) {
		    	cell = row.createCell(j+1); cell.setCellValue( (double) collection.getSeries(j).getY(i) );
	    	}
	    }
	    try 
	    {
	        //Write the workbook in file system
	        FileOutputStream out = new FileOutputStream( new File(outputFileName) );
	        workbook.write(out);
	        out.close();
	        System.out.println("The trustworthiness values are written successfully in an excel file.");
	    } 
	    catch (Exception e)
	    {
	        e.printStackTrace();
	    }
	}
	
	
	public static void main(String [] args) {
		test();
	}

	public static void test() {
		ExcelToPOJO o = new ExcelToPOJO();
		ArrayList<Record> records = o.read("C:\\Users\\Ghazaros\\Desktop\\CostTrustworthinessRecords\\record0.xlsx");
		for (int i = 0; i < records.size(); ++i)
			System.out.print( records.get(i).toString() );
		System.out.println();
		
//		o.write( records.get(0) );
		o.write(records);
//		o.getNewFileName();
	}

}
