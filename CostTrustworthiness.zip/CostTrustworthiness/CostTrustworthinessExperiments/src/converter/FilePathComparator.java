package converter;

import java.util.Comparator;

public class FilePathComparator<File> implements Comparator<File> {

	public int getFileIndex(String fileName) {
		int beginIndex = fileName.indexOf("record") + "record".length();
    	int endIndex = fileName.length() - ".xlsx".length();
    	int fileIndex = Integer.valueOf( fileName.substring(beginIndex, endIndex) );
    	
    	return fileIndex;
	}
	
	public String getNextNewFileName(String fileName) {
		
		int beginIndex = fileName.indexOf("record") + "record".length();
    	int endIndex = fileName.length() - ".xlsx".length();
    	int fileIndex = Integer.valueOf( fileName.substring(beginIndex, endIndex) );
    	
    	++fileIndex ;
    	String newFileName = fileName.substring(0, beginIndex) + Integer.toString(fileIndex) + ".xlsx";
    	
    	return newFileName;
	}
	
	@Override
	public int compare(File f1, File f2) {
		// TODO Auto-generated method stub
		return this.getFileIndex(f1.toString()) - this.getFileIndex(f2.toString());
	}

	

}
