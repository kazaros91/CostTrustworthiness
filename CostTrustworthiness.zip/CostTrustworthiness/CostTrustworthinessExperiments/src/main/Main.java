package main;

import logic.Experiments;

public class Main {
	
	public static void main(String [] args) {
		test();
	}
	
	public static void test() {
		int maxNumberOfUsers = 128;	
		Experiments.test(maxNumberOfUsers);
//		Reputation.test(32);
//		Reputation.test(64);
//		Reputation.test(128);
	}
	
}
