package logic;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

import org.javatuples.Pair;
import org.jfree.data.xy.XYSeries;

import converter.ExcelToPOJO;
import initializing.InitializingHelper;
import pojo.Record;
import view.PlotXY;
import view.PlotXYExcel;

public class Experiments {
	
	public static void test(int maxNumberOfUsers) {
		
		int maxNumberOfBuyers = (int) Math.ceil(0.8 * maxNumberOfUsers);
		int maxNumberOfInteractions = (int) Math.ceil(1.5 * maxNumberOfUsers);
		
		test(maxNumberOfUsers, maxNumberOfBuyers, maxNumberOfInteractions);
	}
	
	public static void test(int maxNumberOfUsers, int maxNumberOfBuyers, int maxNumberOfInteractions) { 	
		ExcelToPOJO converter = new ExcelToPOJO();
		// uncomment to read records from a file
//		ArrayList<Record> records = converter.read(
//			"C:\\Users\\Ghazaros\\Desktop\\CostTrustworthinessFigures\\FiguresNonEditablePng\\Scenario3\\Figure3_record113.xlsx");   //  read when want to experiment with a given records
		// comment out the following two lines when reading from a file of records
		ArrayList<Record> records = InitializingHelper.random(maxNumberOfUsers, maxNumberOfBuyers, maxNumberOfInteractions);
		converter.write(records);
		
		// printing the records in the console
		System.out.println("Records = " + records);
		for (int i=0; i < records.size(); ++i) {
			System.out.println("Record at " + i + ": " + records.get(i));
		}

		scenario1(records, maxNumberOfUsers);
		scenario2(records, maxNumberOfUsers);
		scenario3(records, maxNumberOfUsers);
		scenario4(records, maxNumberOfUsers);
	}
	
	public static void scenario1(ArrayList<Record> records, int maxNumberOfUsers) 
	{	
		XYSeries seriesCost = new XYSeries("Cost-Based");
		XYSeries seriesMod = new XYSeries("No-Cost-Based");
		XYSeries seriesBeta = new XYSeries("Traditional-Beta");
		
		// to calculate different reputations
		Reputation repCost = new ReputationCost();
	  	Reputation repMod = new ReputationMod();
	  	Reputation repBeta = new ReputationBeta();
		
	  	Random random = new Random();
	  	int index = random.nextInt(records.size());
		Record record = records.get(index);
		
		int DELTA_MAX = 200;
		for (int delta = 0; delta < DELTA_MAX; ++delta) {  //  iterate and update reputations
//			double I = record.getComplaints() + delta;
//			double cred = rep.getCredibilityOfBuyer( records, record.getClientId() );
				
			// updating!!!
			// update r
			int step = 1;
			int r = record.getPositiveFeeds() + step;
			// update cost
			int deltaCost = record.getCost() / record.getPositiveFeeds();  // added
			int cost = record.getCost() + step*deltaCost;  // added
			// update record
			record.setPositiveFeeds(r);
			record.setBelief();
			record.setPraise( record.getPraise() + step);
			record.setInteractions( record.getInteractions() + step );
			record.setCost(cost);
			// update records
			records.set(index, record);
 			
			// can be put in array list
			// calculating reputation with cost	
			double reputationCost = repCost.getReputationOfSeller( records, record.getServiceProviderId() );
			double credibilityCost = repCost.getCredibilityOfBuyer(records, record.getClientId() );
//			System.out.println("repCost = " +  reputationCost + " cred = " + credibilityCost);
			seriesCost.add(r, reputationCost);   //  jfree chart	
						
			// calculating reputation with cost	
			double reputationMod = repMod.getReputationOfSeller( records, record.getServiceProviderId() );
			double credibilityMod = repMod.getCredibilityOfBuyer(records, record.getClientId() );
//			System.out.println("repMod = " +  reputationMod + " cred = " + credibilityMod);
			seriesMod.add(r, reputationMod);   //  jfree chart	
						
			// calculating classical Bayesian Beta reputation
			double reputationBeta = repBeta.getReputationOfSeller( records, record.getServiceProviderId() );
			seriesBeta.add(r, reputationBeta);   //  jfree chart
		}
		
		PlotXY p = new PlotXY( "TRUSTWORTHINESS EXPERIMENTS: the maximum number users = " + maxNumberOfUsers, 
				               "The impact of false praise from buyer: clientId = " + record.getClientId() +
															  " on the trustworthiness of the seller: serviceProviderId = " + record.getServiceProviderId(),
												              "The number of positive feedbacks from client (clientId = " + record.getClientId() + ")",
													                  "Trustworthiness" );
		
		PlotXYExcel p1 = new PlotXYExcel( "TRUSTWORTHINESS EXPERIMENTS: the maximum number users = " + maxNumberOfUsers, 
								"The impact of false praise from buyer: clientId = " + record.getClientId() +
												  " on the trustworthiness of the seller: serviceProviderId = " + record.getServiceProviderId(),
									              "The number of positive feedbacks from client (clientId = " + record.getClientId() + ")",
										                  "Trustworthiness" );	
		p.add(seriesCost);
		p.add(seriesMod);
		p.add(seriesBeta);
		p.draw();
		p1.add(seriesCost);
		p1.add(seriesMod);
		p1.add(seriesBeta);
		p1.draw();
	}
	
	public static void scenario2(ArrayList<Record> records, int maxNumberOfUsers)//, List<Reputation> reps)  //  DEL
	{
		XYSeries seriesCost = new XYSeries("Cost-Based");
		XYSeries seriesMod = new XYSeries("No-Cost-Based");
		XYSeries seriesBeta = new XYSeries("Traditional-Beta");

	  	Reputation repCost = new ReputationCost();   //  to calculate reputations
	  	Reputation repMod = new ReputationMod();
	  	Reputation repBeta = new ReputationBeta();
		
	  	Random random = new Random();
	  	int index = random.nextInt(records.size());
//		int index = Record.getMaxFrom(records, new Record.ReputationComparator(reputations) );
		Record record = records.get(index);
		
		int DELTA_MAX = 200;
		for (int delta = 0; delta < DELTA_MAX; ++delta) {  //  iterate and update reputations
//			double I = record.getComplaints() + delta;
//			double cred = rep.getCredibilityOfBuyer( records, record.getClientId() );
				
			// updating!!!
			// update s
			int step = 1;
			int s = record.getNegativeFeeds() + step;
			int deltaLoss = record.getLoss() / record.getNegativeFeeds();  // added
			int loss = record.getLoss() + step*deltaLoss;  // added
			// update record
			record.setNegativeFeeds(s);
			record.setBelief();
			record.setComplaints(record.getComplaints() + step);
			record.setInteractions(record.getInteractions() + step*deltaLoss);
			record.setLoss(loss);
			// update records
			records.set(index, record);
			
			// calculating modifified new reputation
//			double reputation = rep.getReputationOfSeller( records, record.getServiceProviderId() );   //  to calculate rep
//			series.add(s, reputation);   //  jfree chart
				
			// calculating reputation with cost	
			double reputationCost = repCost.getReputationOfSeller( records, record.getServiceProviderId() );
			double credibilityCost = repCost.getCredibilityOfBuyer(records, record.getClientId() );
//			System.out.println("repCost = " +  reputationCost + " cred = " + credibilityCost);
			seriesCost.add(s, reputationCost);   //  jfree chart	
			
			// calculating reputation with cost	
			double reputationMod = repMod.getReputationOfSeller( records, record.getServiceProviderId() );
			double credibilityMod = repMod.getCredibilityOfBuyer(records, record.getClientId() );
//			System.out.println("repMod = " +  reputationMod + " cred = " + credibilityMod);
			seriesMod.add(s, reputationMod);   //  jfree chart	
			
			// calculating classical Bayesian reputation
			double reputationBeta = repBeta.getReputationOfSeller( records, record.getServiceProviderId() );
			seriesBeta.add(s, reputationBeta);   //  jfree chart	
		}
		
		PlotXY p = new PlotXY( "TRUSTWORTHINESS EXPERIMENTS: the maximum number users = " + maxNumberOfUsers, 
		   "The impact false complaints rating from buyer: clientId = " + record.getClientId() +
										  " on the trustworthiness of the seller: serviceProviderId = " + record.getServiceProviderId(),
							              "The number of negative feedbacks from buyer (clientId = " + record.getClientId() + ")",
								                  "Trustworthiness" );
		
		PlotXYExcel p1 = new PlotXYExcel( "TRUSTWORTHINESS EXPERIMENTS: the maximum number users = " + maxNumberOfUsers, 
				   "The impact false complaints rating from buyer: clientId = " + record.getClientId() +
												  " on the trustworthiness of the seller: serviceProviderId = " + record.getServiceProviderId(),
									              "The number of negative feedbacks from buyer (clientId = " + record.getClientId() + ")",
										                  "Trustworthiness" );
		
		p.add(seriesCost);
		p.add(seriesMod);
		p.add(seriesBeta);
		p.draw();
		p1.add(seriesCost);
		p1.add(seriesMod);
		p1.add(seriesBeta);
		p1.draw();
	}
	
	public static void scenario3(ArrayList<Record> records, int maxNumberOfUsers)
	{
		XYSeries seriesCost = new XYSeries("Cost-Based");
		XYSeries seriesMod = new XYSeries("No-Cost-Based");
		XYSeries seriesBeta = new XYSeries("Traditional-Beta");

	  	ReputationCost repCost = new ReputationCost();   //  With Cost Reputation
	  	Reputation repMod = new ReputationMod();   //  Without Cost Reputation
	  	Reputation repBeta = new ReputationBeta();   //  Standard Bayesian
	  	
	  	Random random = new Random();
		int index = random.nextInt( records.size() );
//		int index = 20;
		Record record = records.get(index);
		int serviceProviderId = record.getServiceProviderId();
		List<Reputation> R = new ArrayList<Reputation>();
		R.add(repCost); R.add(repMod); R.add(repBeta);
		List<XYSeries> S = new ArrayList<XYSeries>();
		S.add(seriesCost); S.add(seriesMod); S.add(seriesBeta);
		calculateSeriesRandomlyIncreasing(records, serviceProviderId, R, S);

		PlotXY p1 = new PlotXY( "TRUSTWORTHINESS EXPERIMENTS: the maximum number users = " + maxNumberOfUsers,
			"The impact on the trustworthiness of the service provider (serviceProviderId = " + record.getServiceProviderId() + ") "
			+ "while he provides unsatisfactory service"
			+ "with random but bigger than average cost",
			"The total number of positive feedbacks from the servieProvider's all clients",
								                  "Trustworthiness" );
		
		PlotXYExcel p = new PlotXYExcel( "TRUSTWORTHINESS EXPERIMENTS: the maximum number users = " + maxNumberOfUsers,
				"The impact on the trustworthiness of the service provider (serviceProviderId = " + record.getServiceProviderId() + ") "
				+ "while he provides unsatisfactory service"
				+ "with random but bigger than average cost",
				"The total number of positive feedbacks from the servieProvider's all clients",
									                  "Trustworthiness" );
		
		p.add(seriesCost);
		p.add(seriesMod);
		p.add(seriesBeta);
		p.draw();
		
		p1.add(seriesCost);
		p1.add(seriesMod);
		p1.add(seriesBeta);
		p1.draw();
	}
	
	public static void calculateSeriesRandomlyIncreasing(List<Record> records, int serviceProviderId,
			List<Reputation> reputations,
			List<XYSeries> series) {
		
			List<Integer> clients = getAllClientsIndexes(records, serviceProviderId); 
			int totalInteractions = getTotalPositiveInteractions(records, serviceProviderId);
			
			Random random =  new Random();
			int DELTA_MAX = 150;
			for (int delta = 0; delta < DELTA_MAX; ++delta) {  
				int clientIndex = random.nextInt(clients.size());
				int index = clients.get(clientIndex);
				Record record = records.get(index);
				
				// updating!!!
				// update r
				int step = 1;
				totalInteractions = totalInteractions + 1;
				int r = record.getPositiveFeeds() + step;
				// update cost
				int deltaCost = record.getCost() / record.getPositiveFeeds();  // added
				deltaCost *= (2 + random.nextInt(4));    
				int cost = record.getCost() + step*deltaCost;  // added
				// update record
				record.setPositiveFeeds(r);
				record.setBelief();
				record.setPraise(record.getPraise() + step);
				record.setInteractions(record.getInteractions() + step);
				record.setCost(cost);
				// update records
				records.set(index, record);
					
				for ( int i=0; i < reputations.size(); ++i ) {
					// calculating reputation2
					double reputation = reputations.get(i).getReputationOfSeller(records, record.getServiceProviderId() );
					double credibility = reputations.get(i).getCredibilityOfBuyer(records, record.getClientId() );
//					System.out.println("repCost = " +  reputation1 + " cred = " + credibility1);
					System.out.println("serviceProviderId: " + record.getServiceProviderId());
					series.get(i).add(totalInteractions, reputation);   //  jfree chart	
				}
				
			}
	}
	
	public static void scenario4(ArrayList<Record> records, int maxNumberOfUsers)
	{
		XYSeries seriesCost = new XYSeries("Cost-Based");
		XYSeries seriesMod = new XYSeries("No-Cost-Based");
		XYSeries seriesBeta = new XYSeries("Traditional-Beta");

	  	ReputationCost repCost = new ReputationCost();   //  With Cost Reputation
	  	Reputation repMod = new ReputationMod();   //  Without COst Reputation
	  	Reputation repBeta = new ReputationBeta();   //  Standard Bayesian
	  	
	  	Random random = new Random();
		int index = random.nextInt( records.size() );
		Record record = records.get(index);
		int serviceProviderId = record.getServiceProviderId();
		List<Reputation> R = new ArrayList<Reputation>();
		R.add(repCost); R.add(repMod); R.add(repBeta);
		List<XYSeries> S = new ArrayList<XYSeries>();
		S.add(seriesCost); S.add(seriesMod); S.add(seriesBeta);
//		XYSeries [] S = {seriesCost, seriesMod, seriesBeta};
		calculateSeriesRandomlyDecreasing(records, serviceProviderId, R, S);

		PlotXY p = new PlotXY( "TRUSTWORTHINESS EXPERIMENTS: the maximum number users = " + maxNumberOfUsers,
				"The impact on the trustworthiness of the service provider (serviceProviderId = " + record.getServiceProviderId() + ") "
				+ " with random but bigger than average loss"
				+ " serviceProviderId = " + record.getServiceProviderId(),
							              "The total number of negative feedbacks from the servieProvider's all clients",
								                  "Trustworthiness" );
		
		PlotXYExcel p1 = new PlotXYExcel(  "TRUSTWORTHINESS EXPERIMENTS: the maximum number users = " + maxNumberOfUsers,
				"The impact on the trustworthiness of the service provider (serviceProviderId = " + record.getServiceProviderId() + ") "
				+ " with random but bigger than average loss"
				+ " serviceProviderId = " + record.getServiceProviderId(),
							              "The total number of negative feedbacks from the servieProvider's all clients",
								                  "Trustworthiness" );
		
		p.add(seriesCost);
		p.add(seriesMod);
		p.add(seriesBeta);
		p.draw();
		p1.add(seriesCost);
		p1.add(seriesMod);
		p1.add(seriesBeta);
		p1.draw();
	}
	
	public static void calculateSeriesRandomlyDecreasing (List<Record> records, int serviceProviderId,
			List<Reputation> reputations,
			List<XYSeries> series) {
		
			List<Integer> clients = getAllClientsIndexes(records, serviceProviderId); 
			int totalInteractions = getTotalNegativeInteractions(records, serviceProviderId);
			
			Random random =  new Random();
			int DELTA_MAX = 150;
			for (int delta = 0; delta < DELTA_MAX; ++delta) {  
				int clientIndex = random.nextInt(clients.size());
				int index = clients.get(clientIndex);
				Record record = records.get(index);
				
				// updating!!!
				// update s
				int step = 1;
				totalInteractions = totalInteractions + 1;
				int s = record.getNegativeFeeds() + step;
				// update loss
				int deltaLoss = record.getLoss() / record.getNegativeFeeds();  // added
				deltaLoss *= (2 + random.nextInt(4));    
				int loss = record.getLoss() + step*deltaLoss;  // added
				// update record
				record.setNegativeFeeds(s);
				record.setBelief();
				record.setComplaints(record.getComplaints() + step);
				record.setInteractions(record.getInteractions() + step);
				record.setLoss(loss);
				// update records
				records.set(index, record);
				
				for ( int i=0; i < reputations.size(); ++i ) {
					// calculating reputation2
					double reputation = reputations.get(i).getReputationOfSeller(records, record.getServiceProviderId() );
					double credibility = reputations.get(i).getCredibilityOfBuyer(records, record.getClientId() );
//					System.out.println("repCost = " +  reputation1 + " cred = " + credibility1);
					System.out.println("serviceProviderId: " + record.getServiceProviderId());
					series.get(i).add(totalInteractions, reputation);   //  jfree chart	
				}
				
			}
	}
	
	
	private static List<Integer> getAllClientsIndexes(List<Record> records, int serviceProviderId) {
		List<Integer> clientsIndexes = new ArrayList<Integer>(); 
		for ( int i=0; i < records.size(); ++i ) {
			if ( records.get(i).getServiceProviderId() == serviceProviderId ) 
				clientsIndexes.add(i);
		}
		return clientsIndexes;
	}
	
	private static int getTotalPositiveInteractions(List<Record> records, int serviceProviderId) {
		int totalPositive = 0;
		for ( int i=0; i < records.size(); ++i ) {
			if ( records.get(i).getServiceProviderId() == serviceProviderId ) 
				totalPositive += records.get(i).getPositiveFeeds(); 
		}
		return totalPositive;
	}
	
	private static int getTotalNegativeInteractions(List<Record> records, int serviceProviderId) {
		int totalNegative = 0;
		for ( int i=0; i < records.size(); ++i ) {
			if ( records.get(i).getServiceProviderId() == serviceProviderId ) 
				totalNegative += records.get(i).getNegativeFeeds(); 
		}
		return totalNegative;
	}
}

