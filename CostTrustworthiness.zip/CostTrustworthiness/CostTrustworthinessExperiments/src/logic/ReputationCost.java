package logic;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;

import org.javatuples.Pair;
import org.jfree.data.xy.XYSeries;

import converter.ExcelToPOJO;
import initializing.InitializingHelper;
import pojo.Record;
import view.PlotXY;
import view.PlotXYExcel;

public class ReputationCost implements Reputation {
	
	private ArrayList<Record> records;
	
	public ReputationCost() {}
	
	public HashMap<Integer, Double> getCredibilities(final ArrayList<Record> records) {
		if ( records.isEmpty() )
			return null;
		
		HashMap<Integer, Double> credibilities = new HashMap<Integer, Double>();
		
		records.sort( new Record.ClientIdComparator() );		
		for ( int i = 0; i < records.size(); ) {	
			
			Record record = records.get(i);	
			int clientId = record.getClientId();
			int P = 0;
			int I = 0;
			do {     //  for buyer with clientId = id calculate the total number of positive and negative feedbacks from sellers
				record = records.get(i);	
				P += record.getPraise();
				I += record.getInteractions();
				
				++i;
			}
			while ( i < records.size() && records.get(i).getClientId() == clientId  );   //  verify that is the same seller
			
			credibilities.put(clientId, (double) P / (double) I);
		}

		return credibilities;
	}
	
	public HashMap<Integer, Double> getReputations(final ArrayList<Record> records) {
		HashMap<Integer, Double> credibilities = this.getCredibilities(records);
		return this.getReputations(records, credibilities);
	}
	
	public HashMap<Integer, Double> getReputations(final ArrayList<Record> records, 
														HashMap<Integer, Double> credibilities) {
		if ( records.isEmpty() )
			return null;
		
		HashMap<Integer, Double> reputations = new HashMap<Integer, Double>();
		
		records.sort( new Record.ServiceProviderIdComparator() );
		for ( int i = 0; i < records.size(); ) {
			    
		    Record record = records.get(i);
		    int serviceProviderId = record.getServiceProviderId();
		    double rep = 0;
		    int numberOfClients = 0;
			do {
				record = records.get(i);
				double c = credibilities.get( record.getClientId());
				rep = updateReputation(rep, record, c);
				
				++i;
				++numberOfClients;
			}
			while( i < records.size() && records.get(i).getServiceProviderId() == serviceProviderId );   //  verify that is the same seller
			
			reputations.put(serviceProviderId, rep / (double) numberOfClients);
		}
			
		return reputations;
	}
	
	private double updateReputation(double rep, Record record, double cred) {
		// all at ij index
		double belief = record.getBelief();
		double benefit = record.getCost() / (double) ( record.getCost() + record.getLoss() );
		double trust = belief * benefit;
		rep += cred * trust;
		
		return rep;
	}
	
	@Override
	public double getReputationOfSeller(final List<Record> records, int serviceProviderId) {
		
		double rep = 0;
		int numberOfClients = 0;
		for ( int i = 0; i < records.size(); ++i ) {
			if ( records.get(i).getServiceProviderId() == serviceProviderId ) {
				Record record = records.get(i);
				double credibility = this.getCredibilityOfBuyer(records, record.getClientId());
				rep = updateReputation(rep, record, credibility);
				++numberOfClients;
			}	
		}
		
		return rep / (double) numberOfClients;
	}	
	
	@Override
	public double getCredibilityOfBuyer(final List<Record> records, int clientId ) {
		
		int P = 0;
		int I = 0;
		for ( int i = 0; i < records.size(); ++i ) {
			if ( records.get(i).getClientId() == clientId ) {
				Record record = records.get(i);
				P += record.getPraise();
				I += record.getInteractions();
			}	
		}
		
		return (double) P / (double) I;
	}
	
	
	void print(ArrayList<Record> records, HashMap<Integer, Double> credibilities,
			HashMap<Integer, Double> reputations) 
	{	
		records.sort( new Record.ClientIdComparator() );
		for ( int i = 0; i < records.size(); ++i ) {
		     System.out.println(records.get(i));
		}
		
		System.out.println();
		records.sort( new Record.ServiceProviderIdComparator() );
		for ( int i = 0; i < records.size(); ++i ) {
		     System.out.println(records.get(i));
		}
		
		System.out.println(); System.out.println();
		System.out.println("sorted by trustworthiness");
		records.sort( new Record.ReputationComparator(reputations) );
		for ( int i = 0; i < records.size(); ++i ) {
		     System.out.println( records.get(i) + "   rep =  " + reputations.get( records.get(i).getServiceProviderId() ) );
		}
		
		System.out.println();   System.out.println();
		System.out.println("Credibilities");
		for ( Entry<Integer, Double> entry: credibilities.entrySet() )
			System.out.println( "clientId = " + entry.getKey() + "     " + "credibility = " + entry.getValue() 
			+ "  " + this.getCredibilityOfBuyer(records, entry.getKey() ) );
		
		System.out.println();   System.out.println();   
		System.out.println("Reputations");
		for ( Entry<Integer, Double> entry: reputations.entrySet() )
			System.out.println( "serviceProviderId = " + entry.getKey() + "     " + "reputation = " + entry.getValue()
											+ "  " + this.getReputationOfSeller(records, entry.getKey() )  );	
	}
	
}
