package logic;

import java.util.List;

import pojo.Record;

public class ReputationBeta implements Reputation {
	
	@Override
	public double getReputationOfSeller(final List<Record> records, int serviceProviderId) {
		
		int R = 0;
		int S = 0;
		for ( int i = 0; i < records.size(); ++i ) {
			if ( records.get(i).getServiceProviderId() == serviceProviderId ) {
				Record record = records.get(i);
				R += record.getPositiveFeeds();
				S += record.getNegativeFeeds();
			}	
		}
			
		return (double) (R + 1) / (double) (R + S + 2);
	}

	@Override
	public double getCredibilityOfBuyer(final List<Record> records, int clientId) {
		return 1;
	}
	
}
