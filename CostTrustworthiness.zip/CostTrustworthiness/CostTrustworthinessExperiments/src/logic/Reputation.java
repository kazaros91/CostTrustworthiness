package logic;

import java.util.List;

import pojo.Record;

public interface Reputation {
	
	double getCredibilityOfBuyer(List<Record> records, int clientId);
	double getReputationOfSeller(List<Record> records, int serviceProviderId);

}
