package initializing;

import java.util.ArrayList;
import java.util.Random;
import java.util.TreeSet;

import org.javatuples.Pair;

import converter.ExcelToPOJO;
import pojo.Record;

public class InitializingHelper {

	public InitializingHelper() {
		
	}
	
	
	public static ArrayList<Record> random(int maxNumberOfUsers, int maxNumberOfBuyers, int maxNumberOfInteractions) {
		Random rand = new Random();
		
		ArrayList<Record> records = new ArrayList<Record>();
		TreeSet<Pair> constraints = new TreeSet<Pair>();   //  not to have repeating records
		for (int i = 0; i < maxNumberOfUsers; ++i ) {
			Record record = Record.random(maxNumberOfUsers, maxNumberOfBuyers, maxNumberOfInteractions);
			Pair pair = new Pair( record.getClientId(), record.getServiceProviderId() );
			if ( !constraints.contains(pair) ) {
				records.add(record);
				constraints.add(pair);
			}
		}
			
		return records;
	}
	
	
	public static void main(String [] args) {
		test();
	}
	
	public static void test() {
		int maxNumberOfUsers = 8;
		int maxNumberOfBuyers = 4;
		int maxNumberOfInteractions = 10;
		ArrayList<Record> records = InitializingHelper.random(maxNumberOfUsers, maxNumberOfBuyers, maxNumberOfInteractions);
		
		ExcelToPOJO converter = new ExcelToPOJO ();
		converter.write( records );
		
//		DAO dao = new DAO();
//		for ( int i=0; i < records.size(); ++i )
//			dao.addRecord( records.get(i) );
	}
}
